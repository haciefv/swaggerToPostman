const e={folderStrategy:"Tags",parametersResolution:"Example",includeResponses:!0,includeDeprecated:!0,saveAs:!1};export{e as D};
